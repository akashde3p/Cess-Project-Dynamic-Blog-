# i = int(input("enter the length of list"))
# ls = []
# for a in range(i):
#     x = input()
#     ls.append(x)
# ls.sort()
# for h in ls:
#     print(ls)
#
p=input()
s=p.split(",")
s.sort()

for i in s:
    if i=="\r\n" or i=="\n" or i=="\r" or s.index(i)==0:
        continue
    print(s.index(i),"->",i)


    # count = count + 1
# out = []
# buff = []
# for c in your_str:
#     if c == '\n':
#         out.append(''.join(buff))
#         buff = []
#     else:
#         buff.append(c)
# else:
#     if buff:
#        out.append(''.join(buff))
#
# print out
